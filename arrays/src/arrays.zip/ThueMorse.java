public class ThueMorse {
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int[] choices = {0, 1};

        for (int i = 0; i < n; i++) {
            boolean state = false;

            int[] r = new int[n];
            
            for (int j = 0; j < n; j++) {
                r[j] = choices[i];
            }
        }


    }
}
